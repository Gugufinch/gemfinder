export function BrainFireLogo({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="flame" x1="6" y1="2" x2="26" y2="24" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FBBF24" />
          <stop offset="0.5" stopColor="#F97316" />
          <stop offset="1" stopColor="#EF4444" />
        </linearGradient>
      </defs>
      <path
        d="M17.8 2.5c1.8 2.3 2.4 4 2.1 5.8 1.9-.8 3.5-2.3 4.2-4 2.6 2.5 3.8 5.4 3.8 8.5 0 6-4.8 10.8-11 10.8S6 18.8 6 12.9c0-2.8 1-5.3 2.9-7.3.5 1.6 1.5 2.8 3 3.6.2-2.4 1.2-4.6 5.9-6.7Z"
        fill="url(#flame)"
      />
      <path
        d="M10.2 16.2c0-3.4 2.8-6.2 6.2-6.2s6.2 2.8 6.2 6.2-2.8 6.2-6.2 6.2-6.2-2.8-6.2-6.2Zm3-1.2c0 .7.5 1.3 1.2 1.3.6 0 1.1-.6 1.1-1.3 0-.7-.5-1.3-1.1-1.3-.7 0-1.2.6-1.2 1.3Zm3.8 0c0 .7.5 1.3 1.2 1.3.6 0 1.1-.6 1.1-1.3 0-.7-.5-1.3-1.1-1.3-.7 0-1.2.6-1.2 1.3ZM13 19.5h6.7c-.6 1.2-1.9 2-3.3 2-1.5 0-2.9-.8-3.4-2Z"
        fill="#FFF7ED"
        fillOpacity="0.94"
      />
    </svg>
  );
}
