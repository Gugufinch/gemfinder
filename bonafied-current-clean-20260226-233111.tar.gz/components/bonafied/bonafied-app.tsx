'use client';

import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, LayoutGroup, motion } from 'framer-motion';
import { Bell, Bookmark, FolderClosed, Rss, Search, Sparkles, VolumeX } from 'lucide-react';
import { BrainFireLogo } from '@/components/bonafied/brain-fire-logo';
import { CommandPalette } from '@/components/bonafied/command-palette';
import { CHANNEL_LABELS, CHANNEL_ORDER, DEFAULT_TIMEZONE } from '@/lib/bonafied/constants';
import { formatTimestamp, relativeTime } from '@/lib/bonafied/time';
import { Channel, Dossier, SearchResult, SignalResponse, StoryWithCluster, UserPreferences } from '@/lib/bonafied/types';

type SignalPayload = SignalResponse & {
  filedStoryIds: string[];
  live: {
    lastIngestAt: string;
    ingestCounter: number;
    recentCount: number;
  };
};

interface BonafiedAppProps {
  initialPayload: SignalPayload;
  initialPreferences: UserPreferences;
  initialDossiers: Dossier[];
  userId: string;
}

export function BonafiedApp({ initialPayload, initialPreferences, initialDossiers, userId }: BonafiedAppProps) {
  const [channel, setChannel] = useState<Channel>(initialPayload.channel);
  const [payload, setPayload] = useState<SignalPayload>(initialPayload);
  const [preferences, setPreferences] = useState<UserPreferences>(initialPreferences);
  const [selectedStoryId, setSelectedStoryId] = useState(initialPayload.hero?.id || '');
  const [loading, setLoading] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [commandQuery, setCommandQuery] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [cursorIndex, setCursorIndex] = useState(0);
  const [magicEmail, setMagicEmail] = useState('');
  const [magicMessage, setMagicMessage] = useState('');
  const [dossiers, setDossiers] = useState<Dossier[]>(initialDossiers);
  const [newSignalCount, setNewSignalCount] = useState(initialPayload.newSignalCount || 0);
  const [liveCounter, setLiveCounter] = useState(initialPayload.live.ingestCounter);

  const filedSet = useMemo(() => new Set(payload.filedStoryIds), [payload.filedStoryIds]);

  const allStories = useMemo(() => {
    const map = new Map<string, StoryWithCluster>();
    if (payload.hero) {
      map.set(payload.hero.id, payload.hero);
    }

    for (const row of payload.rows) {
      for (const story of row.stories) {
        if (!map.has(story.id)) {
          map.set(story.id, story);
        }
      }
    }

    return [...map.values()];
  }, [payload]);

  const selectedStory =
    allStories.find((story) => story.id === selectedStoryId) || payload.hero || allStories[0] || null;

  useEffect(() => {
    document.body.dataset.accent = preferences.accent;
  }, [preferences.accent]);

  useEffect(() => {
    if (!selectedStoryId && payload.hero) {
      setSelectedStoryId(payload.hero.id);
    }
  }, [payload.hero, selectedStoryId]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement;
      const typingTarget = target?.tagName === 'INPUT' || target?.tagName === 'TEXTAREA';

      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setCommandOpen(true);
        return;
      }

      if (commandOpen || typingTarget) {
        return;
      }

      if (event.key.toLowerCase() === 'j') {
        event.preventDefault();
        moveCursor(1);
        return;
      }

      if (event.key.toLowerCase() === 'k') {
        event.preventDefault();
        moveCursor(-1);
        return;
      }

      if (event.key === 'Enter') {
        event.preventDefault();
        const focused = allStories[cursorIndex];
        if (focused) {
          setSelectedStoryId(focused.id);
        }
        return;
      }

      if (event.key.toLowerCase() === 's' && selectedStory) {
        event.preventDefault();
        void toggleFiled(selectedStory.id);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [commandOpen, allStories, cursorIndex, selectedStory]);

  useEffect(() => {
    const id = window.setInterval(() => {
      void pollLiveMeta();
    }, 30_000);

    return () => window.clearInterval(id);
  }, [liveCounter]);

  useEffect(() => {
    if (!commandOpen) {
      setCommandQuery('');
      setSearchResults([]);
    }
  }, [commandOpen]);

  useEffect(() => {
    const trimmed = commandQuery.trim();
    if (!trimmed) {
      setSearchResults([]);
      return;
    }

    const timeout = window.setTimeout(async () => {
      try {
        const response = await fetch(
          `/api/signals/search?q=${encodeURIComponent(trimmed)}&channel=${encodeURIComponent(channel)}`,
          {
            cache: 'no-store'
          }
        );
        const data = await response.json();
        setSearchResults(data.results || []);
      } catch {
        setSearchResults([]);
      }
    }, 160);

    return () => window.clearTimeout(timeout);
  }, [commandQuery, channel]);

  const moveCursor = (delta: number) => {
    if (!allStories.length) {
      return;
    }
    const next = (cursorIndex + delta + allStories.length) % allStories.length;
    setCursorIndex(next);
    setSelectedStoryId(allStories[next].id);
  };

  const refreshSignals = async (
    nextChannel: Channel,
    options?: {
      q?: string;
      only24h?: boolean;
    }
  ) => {
    setLoading(true);

    try {
      const timezone = preferences.timezone || DEFAULT_TIMEZONE;
      const only24h = options?.only24h ?? preferences.only24h;
      const query = options?.q ?? searchTerm;

      const response = await fetch(
        `/api/signals?channel=${encodeURIComponent(nextChannel)}&timezone=${encodeURIComponent(timezone)}&only24h=${only24h}&userId=${encodeURIComponent(userId)}&q=${encodeURIComponent(query)}`,
        {
          cache: 'no-store'
        }
      );

      const data = (await response.json()) as SignalPayload;
      setPayload(data);
      setNewSignalCount(data.newSignalCount || data.live.recentCount || 0);
      setLiveCounter(data.live.ingestCounter);

      const currentSelected = data.hero || data.rows[0]?.stories[0];
      if (currentSelected) {
        const stillExists = [data.hero, ...data.rows.flatMap((row) => row.stories)].some(
          (story) => story?.id === selectedStoryId
        );
        if (!stillExists) {
          setSelectedStoryId(currentSelected.id);
          setCursorIndex(0);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const pollLiveMeta = async () => {
    try {
      const response = await fetch('/api/signals/live', { cache: 'no-store' });
      const live = await response.json();

      if (live.ingestCounter > liveCounter) {
        setNewSignalCount(Math.max(live.recentCount || 0, 1));
      }
    } catch {
      // noop
    }
  };

  const patchPreferences = async (next: Partial<Omit<UserPreferences, 'userId'>>) => {
    const response = await fetch(`/api/preferences?userId=${encodeURIComponent(userId)}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(next)
    });

    const data = await response.json();
    const updated = data.preferences as UserPreferences;
    setPreferences(updated);
    return updated;
  };

  const toggleFiled = async (storyId: string) => {
    const filed = !filedSet.has(storyId);
    const response = await fetch(`/api/filed?userId=${encodeURIComponent(userId)}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ storyId, filed })
    });
    const data = await response.json();

    setPayload((current) => ({
      ...current,
      filedStoryIds: (data.filed || []).map((item: { storyId: string }) => item.storyId)
    }));
  };

  const createDossierFromSelected = async () => {
    if (!selectedStory) {
      return;
    }
    const name = window.prompt('Dossier name');
    if (!name) {
      return;
    }

    const response = await fetch(`/api/dossiers?userId=${encodeURIComponent(userId)}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name,
        storyIds: [selectedStory.id],
        notes: `Created from THE WIRE on ${new Date().toISOString()}`
      })
    });

    const data = await response.json();
    if (data.dossier) {
      setDossiers((current) => [data.dossier, ...current]);
    }
  };

  const addSelectedToDossier = async (dossierId: string) => {
    if (!selectedStory) {
      return;
    }

    const response = await fetch(`/api/dossiers?userId=${encodeURIComponent(userId)}&mode=add-story`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        dossierId,
        storyId: selectedStory.id
      })
    });

    const data = await response.json();
    if (data.dossier) {
      setDossiers((current) => current.map((dossier) => (dossier.id === data.dossier.id ? data.dossier : dossier)));
    }
  };

  const requestMagicLink = async () => {
    if (!magicEmail) {
      return;
    }

    setMagicMessage('Sending magic link...');

    try {
      const response = await fetch('/api/auth/request-link', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email: magicEmail })
      });

      const data = await response.json();
      if (response.ok) {
        setMagicMessage(`Magic link sent. Preview: ${data.previewLink}`);
      } else {
        setMagicMessage(data.error || 'Could not send magic link');
      }
    } catch {
      setMagicMessage('Could not send magic link');
    }
  };

  const onSelectCommandResult = (result: SearchResult) => {
    if (result.type === 'story') {
      setSelectedStoryId(result.id);
      const index = allStories.findIndex((story) => story.id === result.id);
      if (index >= 0) {
        setCursorIndex(index);
      }
    }

    setCommandOpen(false);
  };

  const toggle24Hour = async () => {
    const nextValue = !preferences.only24h;
    const updated = await patchPreferences({ only24h: nextValue });
    await refreshSignals(channel, { only24h: updated.only24h });
  };

  const setAccent = async () => {
    const nextAccent = preferences.accent === 'cobalt' ? 'amber' : 'cobalt';
    await patchPreferences({ accent: nextAccent });
  };

  const onChangeChannel = async (next: Channel) => {
    setChannel(next);
    await refreshSignals(next);
  };

  const applySearch = async () => {
    await refreshSignals(channel, { q: searchTerm });
  };

  return (
    <LayoutGroup>
      <div className="bonafied-root">
        <header className="glass topbar">
          <div className="brand">
            <BrainFireLogo size={22} />
            BONAFIED
          </div>

          <nav className="topbar-center" aria-label="Channels">
            {CHANNEL_ORDER.map((item) => (
              <button
                key={item}
                className={`nav-chip ${channel === item ? 'active' : ''}`}
                onClick={() => {
                  void onChangeChannel(item);
                }}
              >
                {CHANNEL_LABELS[item]}
              </button>
            ))}
          </nav>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button className="command-trigger" onClick={() => setCommandOpen(true)}>
              <Search size={15} />
              Search THE WIRE
              <span className="kbd">⌘K</span>
            </button>

            <button
              className="small-btn"
              onClick={() => {
                void setAccent();
              }}
            >
              Accent: {preferences.accent === 'cobalt' ? 'Cobalt' : 'Amber'}
            </button>

            <div className="live-pill" title={`Last ingest: ${formatTimestamp(payload.live.lastIngestAt, preferences.timezone)}`}>
              <span className="live-dot" />
              {newSignalCount > 0 ? `${newSignalCount} new signals` : 'THE WIRE synced'}
              {newSignalCount > 0 ? (
                <button
                  className="ghost-btn"
                  onClick={() => {
                    setNewSignalCount(0);
                    void refreshSignals(channel);
                  }}
                >
                  Refresh
                </button>
              ) : null}
            </div>
          </div>
        </header>

        <aside className="glass sidebar">
          <section>
            <div className="panel-title">Dossier</div>
            <button className={`side-item ${channel === 'TODAY' ? 'active' : ''}`} onClick={() => void onChangeChannel('TODAY')}>
              <Rss size={16} />
              <span>The Wire</span>
            </button>
            <button className="side-item" onClick={() => selectedStory && void toggleFiled(selectedStory.id)}>
              <Bookmark size={16} />
              <span className={selectedStory && filedSet.has(selectedStory.id) ? 'filed' : ''}>Filed</span>
            </button>
            <button className="side-item" onClick={createDossierFromSelected}>
              <FolderClosed size={16} />
              <span>Dossier</span>
              <span className="side-meta">{dossiers.length}</span>
            </button>
          </section>

          <section>
            <div className="panel-title">Channels</div>
            {CHANNEL_ORDER.filter((item) => item !== 'TODAY').map((item) => (
              <button
                key={item}
                className={`side-item ${channel === item ? 'active' : ''}`}
                onClick={() => {
                  void onChangeChannel(item);
                }}
              >
                <Sparkles size={15} />
                <span>{CHANNEL_LABELS[item]}</span>
              </button>
            ))}
          </section>

          <section>
            <div className="panel-title">Filters</div>
            <div className="toggle">
              <span>Strict last 24h</span>
              <button onClick={() => void toggle24Hour()}>{preferences.only24h ? 'ON' : 'OFF'}</button>
            </div>

            <div className="toggle" style={{ marginTop: 10 }}>
              <span>Timezone</span>
              <span>{preferences.timezone}</span>
            </div>

            <div className="toggle" style={{ marginTop: 10, flexDirection: 'column', alignItems: 'stretch', gap: 8 }}>
              <span style={{ width: '100%' }}>THE WIRE Search</span>
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  style={{
                    flex: 1,
                    borderRadius: 10,
                    border: '1px solid rgba(255,255,255,0.14)',
                    background: 'rgba(255,255,255,0.04)',
                    color: 'var(--text-primary)',
                    padding: '8px 10px',
                    fontSize: 12
                  }}
                  placeholder="Entity, source, topic"
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                />
                <button className="small-btn" onClick={() => void applySearch()}>
                  Go
                </button>
              </div>
            </div>
          </section>

          <section>
            <div className="panel-title">Magic Link</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                value={magicEmail}
                onChange={(event) => setMagicEmail(event.target.value)}
                placeholder="Email"
                style={{
                  flex: 1,
                  borderRadius: 10,
                  border: '1px solid rgba(255,255,255,0.14)',
                  background: 'rgba(255,255,255,0.04)',
                  color: 'var(--text-primary)',
                  padding: '8px 10px',
                  fontSize: 12
                }}
              />
              <button className="small-btn" onClick={() => void requestMagicLink()}>
                Send
              </button>
            </div>
            {magicMessage ? <div style={{ marginTop: 8, color: 'var(--text-tertiary)', fontSize: 11 }}>{magicMessage}</div> : null}
          </section>
        </aside>

        <main className="glass feed-panel">
          <AnimatePresence mode="wait">
            <motion.div
              key={channel}
              initial={{ opacity: 0, x: 42 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -42 }}
              transition={{ duration: 0.32, ease: [0.22, 0.61, 0.36, 1] }}
            >
              {payload.hero ? (
                <section className="hero-wrap fade-slide">
                  <div className="hero-label">Certified Top Story</div>
                  <motion.h1 layoutId={`story-title-${payload.hero.cluster.id}`} className="hero-title">
                    {payload.hero.title}
                  </motion.h1>
                  <div className="hero-meta">
                    <span className="hero-badge">{CHANNEL_LABELS[payload.hero.category]}</span>
                    <span>{payload.hero.sourceName}</span>
                    <span>{formatTimestamp(payload.hero.publishedAt, preferences.timezone)}</span>
                    <span>{relativeTime(payload.hero.publishedAt)}</span>
                    <span>Cluster {payload.hero.cluster.storyIds.length}</span>
                  </div>
                  {payload.hero.imageUrl ? (
                    <img className="hero-image" src={payload.hero.imageUrl} alt="Hero story" loading="eager" />
                  ) : null}
                </section>
              ) : null}

              {loading ? (
                <section className="row-shell">
                  <div className="row-track">
                    <div className="skeleton skeleton-row" />
                    <div className="skeleton skeleton-row" />
                    <div className="skeleton skeleton-row" />
                  </div>
                </section>
              ) : null}

              {!loading && payload.rows.length ? (
                payload.rows.map((row, rowIndex) => (
                  <section className="row-shell fade-slide" style={{ animationDelay: `${rowIndex * 60}ms` }} key={row.channel}>
                    <header className="row-head">
                      <h2 className="row-title">{row.title}</h2>
                      <span className="side-meta">{row.stories.length} clustered signals</span>
                    </header>

                    <div className="row-track">
                      {row.stories.map((story) => {
                        const isSelected = story.id === selectedStory?.id;
                        return (
                          <motion.article
                            key={story.id}
                            className="signal-card"
                            onClick={() => setSelectedStoryId(story.id)}
                            layoutId={`story-card-${story.id}`}
                            style={
                              isSelected
                                ? {
                                    borderColor: 'color-mix(in srgb, var(--accent) 55%, transparent)',
                                    boxShadow: '0 16px 48px rgba(0,0,0,0.34)'
                                  }
                                : undefined
                            }
                          >
                            <div className="signal-top">
                              <span>{story.sourceName}</span>
                              <span className="signal-score">{Math.round(story.rankScore)}</span>
                            </div>

                            <motion.h3 layoutId={`story-title-${story.cluster.id}`} className="signal-title">
                              {story.title}
                            </motion.h3>
                            <p className="signal-summary">{story.summary.slice(0, 140)}...</p>

                            <div className="signal-meta">
                              <span>{formatTimestamp(story.publishedAt, preferences.timezone)}</span>
                              <span>{story.cluster.storyIds.length} sources</span>
                            </div>
                          </motion.article>
                        );
                      })}
                    </div>
                  </section>
                ))
              ) : null}
            </motion.div>
          </AnimatePresence>
        </main>

        <aside className="glass detail-panel">
          {selectedStory ? (
            <motion.div layoutId={`story-card-${selectedStory.id}`}>
              <div className="detail-eyebrow">Active Signal</div>
              <motion.h2 layoutId={`story-title-${selectedStory.cluster.id}`} className="detail-title">
                {selectedStory.title}
              </motion.h2>

              <div className="detail-blurb">{selectedStory.summary}</div>

              <div className="inline-actions detail-block">
                <button className={`small-btn ${filedSet.has(selectedStory.id) ? 'primary' : ''}`} onClick={() => void toggleFiled(selectedStory.id)}>
                  <Bookmark size={14} /> {filedSet.has(selectedStory.id) ? 'Filed' : 'Save to Filed'}
                </button>

                <button
                  className="small-btn"
                  onClick={() => {
                    const entity = selectedStory.entities[0];
                    if (!entity) {
                      return;
                    }
                    const next = preferences.followedEntities.includes(entity)
                      ? preferences.followedEntities.filter((item) => item !== entity)
                      : [...preferences.followedEntities, entity];
                    void patchPreferences({ followedEntities: next });
                  }}
                >
                  <Bell size={14} /> Follow Entity
                </button>

                <button
                  className="small-btn"
                  onClick={() => {
                    const source = selectedStory.sourceName;
                    const next = preferences.mutedSources.includes(source)
                      ? preferences.mutedSources.filter((item) => item !== source)
                      : [...preferences.mutedSources, source];
                    void patchPreferences({ mutedSources: next }).then(() => refreshSignals(channel));
                  }}
                >
                  <VolumeX size={14} /> Mute Source
                </button>
              </div>

              <div className="detail-block">
                <div className="detail-label">Why this matters</div>
                {selectedStory.whyMatters.map((point, idx) => (
                  <p key={`${selectedStory.id}_${idx}`} className="why-item">
                    {point}
                  </p>
                ))}
              </div>

              <div className="detail-block">
                <div className="detail-label">Entities</div>
                <div className="entity-row">
                  {selectedStory.entities.map((entity) => (
                    <button
                      key={entity}
                      className="entity-pill"
                      onClick={() => {
                        setSearchTerm(entity);
                        void refreshSignals(channel, { q: entity });
                      }}
                    >
                      {entity}
                    </button>
                  ))}
                </div>
              </div>

              <div className="detail-block">
                <div className="detail-label">Cluster Sources</div>
                <div className="source-list">
                  {[selectedStory, ...selectedStory.additionalSources].map((story) => (
                    <a key={story.id} className="source-link" href={story.url} target="_blank" rel="noreferrer">
                      <span>
                        {story.sourceName} • {story.title}
                      </span>
                      <span>{relativeTime(story.publishedAt)}</span>
                    </a>
                  ))}
                </div>
              </div>

              <div className="detail-block">
                <div className="detail-label">Dossiers</div>
                <div className="inline-actions">
                  <button className="small-btn primary" onClick={createDossierFromSelected}>
                    Create Dossier
                  </button>
                  {dossiers.slice(0, 3).map((dossier) => (
                    <button key={dossier.id} className="small-btn" onClick={() => void addSelectedToDossier(dossier.id)}>
                      Add to {dossier.name}
                    </button>
                  ))}
                </div>

                {dossiers[0] ? (
                  <div style={{ marginTop: 10 }}>
                    <a
                      className="source-link"
                      href={`/api/dossiers/${dossiers[0].id}/export?format=markdown&userId=${encodeURIComponent(userId)}`}
                    >
                      <span>Export latest dossier as Markdown</span>
                      <span>Download</span>
                    </a>
                  </div>
                ) : null}
              </div>
            </motion.div>
          ) : (
            <div className="detail-blurb">No active signal selected.</div>
          )}
        </aside>
      </div>

      <CommandPalette
        open={commandOpen}
        query={commandQuery}
        onQueryChange={setCommandQuery}
        results={searchResults}
        onClose={() => setCommandOpen(false)}
        onSelect={onSelectCommandResult}
      />
    </LayoutGroup>
  );
}
