import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

export const runtime = 'nodejs';

const requestSchema = z.object({
  prompt: z.string().trim().min(1).max(30000),
  model: z.string().trim().min(1).max(120).default('gpt-4.1'),
  maxTokens: z.number().int().positive().max(4096).default(1200),
  apiKey: z.string().trim().max(300).optional().default('')
});

type OpenAIResponse = {
  output_text?: string;
  output?: Array<{
    type?: string;
    content?: Array<{ type?: string; text?: string }>;
  }>;
};

function parseOpenAIResponseText(payload: OpenAIResponse): string {
  if (typeof payload?.output_text === 'string' && payload.output_text.trim()) {
    return payload.output_text.trim();
  }
  const parts: string[] = [];
  (payload?.output || []).forEach((item) => {
    if (item?.type !== 'message') return;
    (item?.content || []).forEach((content) => {
      if ((content?.type === 'output_text' || content?.type === 'text') && content?.text) {
        parts.push(content.text);
      }
    });
  });
  return parts.join('\n').trim() || 'No response.';
}

export async function POST(req: NextRequest) {
  const payload = await req.json().catch(() => null);
  const parsed = requestSchema.safeParse(payload);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid AI payload', details: parsed.error.issues }, { status: 400 });
  }

  const { prompt, model, maxTokens, apiKey } = parsed.data;
  const key = (apiKey || process.env.OPENAI_API_KEY || '').trim();
  if (!key) {
    return NextResponse.json({ error: 'Missing OpenAI API key.' }, { status: 400 });
  }

  try {
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`
      },
      body: JSON.stringify({
        model,
        input: prompt,
        max_output_tokens: maxTokens
      })
    });

    const raw = await upstream.text();
    if (!upstream.ok) {
      let msg = `OpenAI error ${upstream.status}`;
      try {
        const parsedError = JSON.parse(raw) as { error?: { message?: string } | string };
        const nested = typeof parsedError?.error === 'string' ? parsedError.error : parsedError?.error?.message;
        msg = nested || msg;
      } catch {}
      return NextResponse.json({ error: msg }, { status: upstream.status });
    }

    const data = JSON.parse(raw) as OpenAIResponse;
    const text = parseOpenAIResponseText(data);
    return NextResponse.json({ ok: true, text });
  } catch (error) {
    console.error('OpenAI proxy failed', error);
    return NextResponse.json({ error: 'AI proxy request failed.' }, { status: 502 });
  }
}
