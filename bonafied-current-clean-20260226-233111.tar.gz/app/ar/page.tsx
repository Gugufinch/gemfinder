import { cookies } from 'next/headers';
import GemFinderApp from '@/gem-finder-v7.jsx';
import ARLogin from './ARLogin';

export default async function ARPage() {
  const cookieStore = await cookies();
  const userId = cookieStore.get('bonafied_user')?.value || '';
  const email = cookieStore.get('bonafied_email')?.value || '';

  if (!userId) {
    return <ARLogin />;
  }

  return <GemFinderApp authUserId={userId} authEmail={email} />;
}
