'use client';

import { FormEvent, useState } from 'react';

type RequestLinkResponse = {
  ok?: boolean;
  error?: string;
  previewLink?: string;
};

export default function ARLogin() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [previewLink, setPreviewLink] = useState('');
  const [sent, setSent] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const clean = email.trim().toLowerCase();
    if (!clean) return;
    setLoading(true);
    setError('');
    setPreviewLink('');
    try {
      const res = await fetch('/api/auth/request-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: clean })
      });
      const data = (await res.json().catch(() => ({}))) as RequestLinkResponse;
      if (!res.ok) {
        setError(data.error || 'Could not send sign-in link');
        return;
      }
      setSent(true);
      if (data.previewLink) setPreviewLink(data.previewLink);
    } catch {
      setError('Network error while requesting sign-in link');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#f3f6fb',
        display: 'grid',
        placeItems: 'center',
        padding: 24,
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: 440,
          background: '#fff',
          border: '1px solid #e3e9f3',
          borderRadius: 16,
          boxShadow: '0 14px 30px rgba(30,41,59,0.08)',
          padding: 24
        }}
      >
        <div style={{ fontSize: 11, letterSpacing: 4, fontWeight: 700, color: '#2563eb', textTransform: 'uppercase', marginBottom: 6 }}>
          Gem Finder v7
        </div>
        <h1 style={{ margin: '0 0 8px', fontSize: 24, color: '#111827' }}>Team Login</h1>
        <p style={{ margin: '0 0 18px', color: '#5f6b84', fontSize: 13 }}>
          Enter your work email to receive a magic sign-in link.
        </p>

        <form onSubmit={submit} style={{ display: 'grid', gap: 10 }}>
          <input
            type="email"
            required
            placeholder="name@company.com"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            style={{
              width: '100%',
              border: '1px solid #cfd8e8',
              borderRadius: 10,
              padding: '10px 12px',
              fontSize: 14,
              outline: 'none',
              color: '#111827',
              boxSizing: 'border-box'
            }}
          />
          <button
            type="submit"
            disabled={loading}
            style={{
              border: 'none',
              borderRadius: 10,
              padding: '10px 12px',
              background: loading ? '#8cb0f7' : '#2563eb',
              color: '#fff',
              fontWeight: 600,
              cursor: loading ? 'wait' : 'pointer'
            }}
          >
            {loading ? 'Sending link...' : 'Send magic link'}
          </button>
        </form>

        {error ? (
          <div style={{ marginTop: 12, fontSize: 12, color: '#dc3f35' }}>{error}</div>
        ) : null}

        {sent ? (
          <div style={{ marginTop: 12, fontSize: 12, color: '#1f9d6a' }}>
            Magic link sent. Open it from your inbox to continue.
          </div>
        ) : null}

        {previewLink ? (
          <div style={{ marginTop: 12, fontSize: 12, color: '#5f6b84' }}>
            Dev preview link:{' '}
            <a href={previewLink} style={{ color: '#2563eb' }}>
              Open sign-in link
            </a>
          </div>
        ) : null}
      </div>
    </div>
  );
}
