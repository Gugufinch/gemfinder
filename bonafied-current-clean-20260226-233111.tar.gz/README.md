# BONAFIED

BONAFIED is a premium same-day news intelligence interface built on Next.js App Router.

## What is live
- `GET /news`: BONAFIED primary UI
- `GET /`: redirects to `/news`
- `GET /admin`: RSS feed admin

Legacy routes (including `/ar`) still exist in this repo but are separate from BONAFIED.
`/ar` now supports magic-link login for team access.

## Core MVP guarantees
- Strict 24h filter (`published_at >= now - 24h`) with timezone support (`America/Chicago` default)
- Verified same-day signal clustering + deduplication
- Channels: Business, Technology, Music Industry, Podcast/Creator Economy
- Three-pane cinematic UI with command palette (`⌘K`) and keyboard controls (`J/K`, `Enter`, `S`)
- Filed stories, dossiers, markdown/text export
- RSS ingestion + cron ingestion endpoint
- Postgres persistence + Redis caching when configured

## Stack
- Next.js 15 + React 19 + TypeScript
- Framer Motion + Lucide
- Postgres (`pg`) for persistence
- Redis for cache acceleration

## Quick start (local dev)
```bash
npm install
npm run dev
```

Open:
- BONAFIED: `http://localhost:3000/news`
- Gem Finder: `http://localhost:3000/ar`

## One-command production-like stack
```bash
cp .env.example .env.local
npm run first
```

`npm run first` does:
1. `docker compose up -d --build`
2. Smoke checks (`/`, `/api/signals/live`, `/api/signals`, `/api/cron/ingest`)

Compose host ports:
- App: `http://localhost:3100` (container runs on 3000 internally)
- Postgres: `localhost:5432`
- Redis: `localhost:6379`

Useful commands:
- `npm run compose:up`
- `npm run compose:down`
- `npm run compose:logs`
- `npm run smoke`

## Environment
See [.env.example](/Users/gugumax/Documents/New%20project/.env.example).

Important keys:
- `DATABASE_URL`
- `REDIS_URL`
- `INGEST_CRON_SECRET`
- `OPENAI_API_KEY`
- `ANTHROPIC_API_KEY` (optional)
- `NEXT_PUBLIC_APP_URL` (used in magic-link URLs)
- `AR_ALLOWED_EMAILS` (optional comma-separated allowlist for `/ar` login)
- `SMTP_*` keys (required to actually email magic links; otherwise use returned preview link in dev)

## Main BONAFIED APIs
- `GET /api/signals`
- `GET /api/signals/live`
- `GET /api/signals/search`
- `POST /api/ingest`
- `POST /api/cron/ingest` (requires secret)
- `GET/POST /api/feeds`
- `PATCH /api/feeds/:id`
- `GET/PATCH /api/preferences`
- `GET/POST /api/filed`
- `GET/POST /api/dossiers`
- `GET /api/dossiers/:id/export?format=markdown|text`
- `POST /api/ai/openai`
- `POST /api/ai/anthropic`

## Notes
- If outbound internet is blocked, BONAFIED continues using seeded stories.
- In live network environments, ingestion fetches external RSS feeds and updates clusters.
