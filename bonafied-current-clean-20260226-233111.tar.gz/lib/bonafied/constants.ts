import { BonafiedCategory, Channel, FeedConfig } from '@/lib/bonafied/types';

export const DEFAULT_TIMEZONE = 'America/Chicago';
export const SAME_DAY_HOURS = 24;

export const CHANNEL_ORDER: Channel[] = [
  'TODAY',
  'BUSINESS',
  'TECHNOLOGY',
  'MUSIC_INDUSTRY',
  'PODCAST_CREATOR'
];

export const CHANNEL_LABELS: Record<Channel, string> = {
  TODAY: 'Today',
  BUSINESS: 'Business',
  TECHNOLOGY: 'Tech',
  MUSIC_INDUSTRY: 'Music',
  PODCAST_CREATOR: 'Podcasts'
};

export const CATEGORY_ROW_LABELS: Record<BonafiedCategory, string> = {
  BUSINESS: 'Business Signals',
  TECHNOLOGY: 'Technology Signals',
  MUSIC_INDUSTRY: 'Music Industry Signals',
  PODCAST_CREATOR: 'Podcast & Creator Signals'
};

export const DEFAULT_SOURCE_CREDIBILITY: Record<string, number> = {
  Reuters: 0.95,
  Bloomberg: 0.94,
  'Wall Street Journal': 0.92,
  CNBC: 0.88,
  'Financial Times': 0.93,
  'TechCrunch': 0.8,
  'The Verge': 0.77,
  Billboard: 0.82,
  Variety: 0.79,
  'Podnews': 0.74,
  'The Information': 0.89,
  'Engadget': 0.72
};

export const DEFAULT_FEEDS: FeedConfig[] = [
  {
    id: 'feed_reuters_business',
    name: 'Reuters Business',
    url: 'https://feeds.reuters.com/reuters/businessNews',
    category: 'BUSINESS',
    credibilityScore: 0.95,
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'feed_cnbc_tech',
    name: 'CNBC Technology',
    url: 'https://www.cnbc.com/id/19854910/device/rss/rss.html',
    category: 'TECHNOLOGY',
    credibilityScore: 0.88,
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'feed_billboard',
    name: 'Billboard',
    url: 'https://www.billboard.com/feed/',
    category: 'MUSIC_INDUSTRY',
    credibilityScore: 0.82,
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'feed_podnews',
    name: 'Podnews',
    url: 'https://podnews.net/rss',
    category: 'PODCAST_CREATOR',
    credibilityScore: 0.74,
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const CATEGORY_KEYWORDS: Record<BonafiedCategory, string[]> = {
  BUSINESS: [
    'market',
    'earnings',
    'acquisition',
    'ipo',
    'funding',
    'revenue',
    'profit',
    'federal reserve',
    'economy'
  ],
  TECHNOLOGY: [
    'ai',
    'software',
    'chip',
    'cloud',
    'startup',
    'apple',
    'google',
    'openai',
    'microsoft'
  ],
  MUSIC_INDUSTRY: [
    'album',
    'label',
    'tour',
    'spotify',
    'artist',
    'chart',
    'royalty',
    'streaming'
  ],
  PODCAST_CREATOR: [
    'podcast',
    'creator',
    'youtube',
    'substack',
    'patreon',
    'ad reads',
    'audience'
  ]
};
