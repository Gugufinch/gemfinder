import crypto from 'node:crypto';
import Parser from 'rss-parser';
import { classifyCategory } from '@/lib/bonafied/classify';
import { clusterStories } from '@/lib/bonafied/cluster';
import { extractEntities } from '@/lib/bonafied/entity-extract';
import { scoreStory } from '@/lib/bonafied/rank';
import { mergeSignals, getFeeds } from '@/lib/bonafied/repository';
import { summarizeStory } from '@/lib/bonafied/summarize';
import { cleanText } from '@/lib/bonafied/text';
import { withinLast24Hours } from '@/lib/bonafied/time';
import { FeedConfig, IngestionResult, StoryRecord } from '@/lib/bonafied/types';

interface RssItem {
  title?: string;
  link?: string;
  pubDate?: string;
  isoDate?: string;
  contentSnippet?: string;
  content?: string;
  creator?: string;
  enclosure?: {
    url?: string;
    type?: string;
  };
  ['media:content']?: Array<{ $?: { url?: string } }>;
}

const parser = new Parser<Record<string, never>, RssItem>({
  timeout: 10_000,
  headers: {
    'User-Agent': 'BONAFIED/1.0'
  }
});

export async function ingestFeeds(): Promise<IngestionResult> {
  const feeds = (await getFeeds()).filter((feed) => feed.active);

  let fetchedFeeds = 0;
  let droppedForTime = 0;
  let droppedForMissingTimestamp = 0;
  let droppedForDupes = 0;

  const ingested: StoryRecord[] = [];

  for (const feed of feeds) {
    try {
      const parsed = await parser.parseURL(feed.url);
      fetchedFeeds += 1;

      for (const item of parsed.items || []) {
        const normalized = normalizeItem(item, feed);
        if (!normalized) {
          droppedForMissingTimestamp += 1;
          continue;
        }

        if (!withinLast24Hours(normalized.publishedAt)) {
          droppedForTime += 1;
          continue;
        }

        if (ingested.some((entry) => canonicalizeUrl(entry.url) === canonicalizeUrl(normalized.url))) {
          droppedForDupes += 1;
          continue;
        }

        ingested.push(normalized);
      }
    } catch {
      continue;
    }
  }

  const scored = ingested.map((story) => ({
    ...story,
    rankScore: scoreStory(story, 1)
  }));

  const clustered = clusterStories(scored);
  const rescored = clustered.stories.map((story) => {
    const cluster = clustered.clusters.find((item) => item.storyIds.includes(story.id));
    return {
      ...story,
      rankScore: scoreStory(story, cluster ? cluster.storyIds.length : 1)
    };
  });

  const merged = await mergeSignals(rescored);

  return {
    fetchedFeeds,
    ingestedStories: merged.inserted,
    droppedForTime,
    droppedForMissingTimestamp,
    droppedForDupes,
    clusteredSignals: merged.clusters,
    ingestedAt: new Date().toISOString()
  };
}

function normalizeItem(item: RssItem, feed: FeedConfig): StoryRecord | null {
  if (!item.title || !item.link) {
    return null;
  }

  const publishedAt = parsePublishedAt(item);
  if (!publishedAt) {
    return null;
  }

  const content = cleanText(item.contentSnippet || item.content || item.title);
  const category = classifyCategory(`${item.title} ${content}`, feed.category);
  const summary = summarizeStory(item.title, content);

  return {
    id: `story_${crypto
      .createHash('sha1')
      .update(`${item.link}:${publishedAt}`)
      .digest('hex')
      .slice(0, 14)}`,
    title: cleanText(item.title),
    url: item.link,
    sourceName: feed.name,
    sourceUrl: feed.url,
    publishedAt,
    category,
    content,
    imageUrl: item.enclosure?.url || item['media:content']?.[0]?.$?.url,
    summary: summary.brief,
    whyMatters: summary.whyMatters,
    entities: extractEntities(`${item.title}. ${content}`),
    rankScore: 0,
    verified: true,
    publishedTimestampKnown: true
  };
}

function parsePublishedAt(item: RssItem): string | null {
  const raw = item.isoDate || item.pubDate;
  if (!raw) {
    return null;
  }

  const timestamp = new Date(raw);
  if (Number.isNaN(timestamp.getTime())) {
    return null;
  }

  return timestamp.toISOString();
}

function canonicalizeUrl(value: string): string {
  try {
    const url = new URL(value);
    url.hash = '';
    url.search = '';
    return url.toString();
  } catch {
    return value;
  }
}
