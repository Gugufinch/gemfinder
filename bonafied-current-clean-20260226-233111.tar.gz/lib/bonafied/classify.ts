import { CATEGORY_KEYWORDS } from '@/lib/bonafied/constants';
import { BonafiedCategory } from '@/lib/bonafied/types';

export function classifyCategory(text: string, fallback?: BonafiedCategory): BonafiedCategory {
  const haystack = text.toLowerCase();

  let bestCategory: BonafiedCategory = fallback || 'TECHNOLOGY';
  let bestScore = fallback ? 0.5 : 0;

  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS) as Array<[
    BonafiedCategory,
    string[]
  ]>) {
    const score = keywords.reduce((acc, keyword) => acc + (haystack.includes(keyword) ? 1 : 0), 0);
    if (score > bestScore) {
      bestScore = score;
      bestCategory = category;
    }
  }

  return bestCategory;
}
