import { cleanText } from '@/lib/bonafied/text';

const KNOWN_ENTITIES = [
  'Apple',
  'Google',
  'Meta',
  'OpenAI',
  'Microsoft',
  'Amazon',
  'Spotify',
  'YouTube',
  'TikTok',
  'Substack',
  'Patreon',
  'Nvidia',
  'Reuters',
  'CNBC',
  'Billboard',
  'Podnews',
  'Universal',
  'Merlin',
  'Federal Reserve',
  'Wall Street Journal'
];

export function extractEntities(input: string): string[] {
  const text = cleanText(input);
  const found = new Set<string>();

  for (const entity of KNOWN_ENTITIES) {
    const expression = new RegExp(`\\b${escapeRegExp(entity)}\\b`, 'i');
    if (expression.test(text)) {
      found.add(entity);
    }
  }

  const properNounPairs = text.match(/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2}\b/g) || [];
  for (const candidate of properNounPairs) {
    if (candidate.length < 3 || candidate.length > 40) {
      continue;
    }
    if (/^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)$/i.test(candidate)) {
      continue;
    }
    found.add(candidate.trim());
    if (found.size > 16) {
      break;
    }
  }

  return [...found].slice(0, 14);
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
